package com.zjmc.generated; import org.bukkit.plugin.java.JavaPlugin; public final class WelcomePlus extends JavaPlugin { public void onEnable(){} }
