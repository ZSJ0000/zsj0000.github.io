# ZJMC-AI 插件生成 MVP
自然语言 + 模板生成 Paper/Spigot 插件源码并使用 Maven 编译为 JAR。
## 启动
后端：`cd backend && python -m venv .venv && pip install -r requirements.txt && cp .env.example .env && uvicorn app.main:app --reload --port 8000`
前端：`cd frontend && npm install && npm run dev`
`.env` 配置 `AI_BASE_URL`、`AI_API_KEY`、`AI_MODEL`，密钥不会写入项目。需要 Java 17+、Maven 3.9+。


## 更新内容
- 模板改为可选，支持“不使用模板（纯自然语言）”。
- 增加 Paper 1.21.8 版本选项。
- 自动生成兼容的 plugin.yml api-version。
- 固定 Vite 4、Rollup 3，适配 Node.js 18 / Windows 7。


## 更新内容
- 模板可选，支持纯自然语言模式。
- 增加 Paper 1.21.8。
- 自动生成兼容的 plugin.yml api-version。
- 固定 Vite 4、Rollup 3，适配 Node.js 18 / Windows 7。
