# ZJMC-AI 插件生成 MVP
自然语言 + 模板生成 Paper/Spigot 插件源码并使用 Maven 编译为 JAR。
## 启动
后端：`cd backend && python -m venv .venv && pip install -r requirements.txt && cp .env.example .env && uvicorn app.main:app --reload --port 8000`
前端：`cd frontend && npm install && npm run dev`
`.env` 配置 `AI_BASE_URL`、`AI_API_KEY`、`AI_MODEL`，密钥不会写入项目。需要 Java 17+、Maven 3.9+。
