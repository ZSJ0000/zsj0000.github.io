import os,re,shutil,subprocess,tempfile,zipfile
from pathlib import Path
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel,Field
load_dotenv();app=FastAPI(title='ZJMC-AI Plugin Generator');app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_methods=['*'],allow_headers=['*'])
ROOT=Path(__file__).resolve().parents[2];TEMPLATE=ROOT/'../plugin-template';WORK=Path(tempfile.gettempdir())/'zjmc-ai-jobs';WORK.mkdir(exist_ok=True)
class Req(BaseModel):
 name:str=Field('WelcomePlus',min_length=2,max_length=40);package_name:str=Field('com.zjmc.generated',pattern=r'^[a-z][a-z0-9_.]*$');server:str='Paper';mc_version:str='1.20.1';template:str='玩家欢迎';prompt:str=Field(min_length=2,max_length=4000)
def safe(s):return re.sub(r'[^A-Za-z0-9_-]','',s)[:40] or 'ZJMCPlugin'
def fallback(r):return f'''package {r.package_name};
import org.bukkit.ChatColor;import org.bukkit.event.EventHandler;import org.bukkit.event.Listener;import org.bukkit.event.player.PlayerJoinEvent;import org.bukkit.plugin.java.JavaPlugin;
public final class {safe(r.name)} extends JavaPlugin implements Listener {{ public void onEnable(){{getServer().getPluginManager().registerEvents(this,this);}} @EventHandler public void onJoin(PlayerJoinEvent e){{e.setJoinMessage(ChatColor.GREEN+"欢迎 "+e.getPlayer().getName()+" 加入服务器！");}} }}'''
async def ai(r):
 key,base,model=os.getenv('AI_API_KEY'),os.getenv('AI_BASE_URL','https://api.openai.com/v1'),os.getenv('AI_MODEL')
 if not key or not model:return None
 msg=f'插件名:{r.name};包名:{r.package_name};服务端:{r.server};版本:{r.mc_version};模板:{r.template};需求:{r.prompt}。类名必须为{safe(r.name)}。只返回Java源码，不要Markdown；禁止Runtime、ProcessBuilder、反射、网络、文件访问。'
 async with httpx.AsyncClient(timeout=90) as c:
  x=await c.post(base.rstrip('/')+'/chat/completions',headers={'Authorization':'Bearer '+key},json={'model':model,'temperature':.2,'messages':[{'role':'system','content':'你生成安全的Bukkit/Paper Java插件源码。'},{'role':'user','content':msg}]});x.raise_for_status();return re.sub(r'^```(?:java)?\s*|\s*```$','',x.json()['choices'][0]['message']['content'].strip())
@app.get('/api/health')
def health():return {'ok':True,'service':'ZJMC-AI'}
@app.post('/api/generate')
async def generate(r:Req):
 job=WORK/next(tempfile._get_candidate_names());shutil.copytree(TEMPLATE,job);source=await ai(r) if os.getenv('AI_API_KEY') and os.getenv('AI_MODEL') else None;used=bool(source);source=source or fallback(r);cls=safe(r.name);d=job/'src/main/java'/Path(*r.package_name.split('.'));d.mkdir(parents=True,exist_ok=True)
 for p in (job/'src/main/java/com/zjmc/generated').glob('*.java'):p.unlink()
 (d/(cls+'.java')).write_text(source,encoding='utf8');(job/'src/main/resources/plugin.yml').write_text(f"name: {cls}\nversion: 1.0.0\nmain: {r.package_name}.{cls}\napi-version: '{r.mc_version[:4]}'\nauthor: ZJMC-AI\n",encoding='utf8');(job/'pom.xml').write_text((job/'pom.xml').read_text().replace('__VERSION__',r.mc_version))
 p=subprocess.run([os.getenv('MAVEN_BIN','mvn'),'-q','package','-DskipTests'],cwd=job,capture_output=True,text=True,timeout=180);log=(p.stdout+'\n'+p.stderr)[-12000:]
 if p.returncode:raise HTTPException(422,'Maven 编译失败：\n'+log)
 jar=next((job/'target').glob('*.jar'));z=WORK/(job.name+'-source.zip')
 with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as q:
  for f in job.rglob('*'):
   if f.is_file() and 'target' not in f.parts:q.write(f,f.relative_to(job))
 return {'job_id':job.name,'plugin_name':cls,'files':[str(f.relative_to(job)) for f in job.rglob('*') if f.is_file() and 'target' not in f.parts],'source_zip':'/api/download/'+z.name,'jar':'/api/download/'+jar.name,'build_log':log,'ai_used':used}
@app.get('/api/download/{name}')
def download(name):
 p=next((p for p in WORK.rglob(name) if p.is_file()),None)
 if not p:raise HTTPException(404,'文件不存在')
 return FileResponse(p,filename=p.name)
