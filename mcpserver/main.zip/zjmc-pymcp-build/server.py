# -*- coding: utf-8 -*-
from __future__ import print_function
import asyncio, datetime, hashlib, json, os, re, secrets, subprocess, time, uuid
from pathlib import Path
from typing import Any, Dict, List
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, StreamingResponse
import uvicorn

BASE = Path(__file__).resolve().parent
DEFAULT_ROOT = r'C:\360安全浏览器下载\zjmc-ai-plugins\zjmc-ai'
DEFAULT = {'bind_host':'127.0.0.1','bind_port':8787,'require_confirmation':True,'allow_write':True,'allow_command':True,'allow_delete':False,'allow_shell':False,'max_file_size':1048576,'command_timeout':120,'max_output_size':20000,'project_root':DEFAULT_ROOT,'require_auth':False,'allowed_ips':[],'access_token':''}
CFG = dict(DEFAULT)
CONFIG_FILE = BASE / 'config.json'
IGNORED = {'.git','node_modules','__pycache__','target','.venv'}
READ_FIXED = {'backend/app/main.py','backend/requirements.txt','frontend/src/main.tsx','frontend/src/style.css','frontend/vite.config.ts','frontend/package.json','plugin-template/pom.xml','README.md'}
WRITE_FIXED = set(READ_FIXED)
COMMANDS = {
 'check_python':(['python','--version'],'root'), 'check_pip':(['python','-m','pip','--version'],'root'),
 'check_node':(['node','--version'],'root'), 'check_npm':(['npm','--version'],'root'),
 'check_java':(['java','-version'],'root'), 'check_maven':(['mvn','-version'],'root'),
 'install_frontend':(['npm','install'],'frontend'), 'build_plugin':(['mvn','package','-DskipTests'],'plugin-template'),
 'start_backend':(['python','-m','uvicorn','app.main:app','--port','8000'],'backend'),
 'start_frontend':(['npm','run','dev'],'frontend')}
SENSITIVE = re.compile(r'(?i)(api[_-]?key|access[_-]?token|refresh[_-]?token|client_secret|password|passwd|authorization|bearer)(\s*[:=]\s*)([^\s,;"\']+)')
app = FastAPI(title='ZJMC-PyMCP', version='0.1.0')
sessions = {}


def load_config():
    global CFG
    CFG = dict(DEFAULT)
    if CONFIG_FILE.exists():
        try:
            data = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
            if isinstance(data, dict):
                for k in DEFAULT:
                    if k in data: CFG[k] = data[k]
        except Exception: pass
    if os.environ.get('MCP_ACCESS_TOKEN'): CFG['access_token'] = os.environ['MCP_ACCESS_TOKEN']
    if os.environ.get('MCP_ALLOWED_IPS'): CFG['allowed_ips'] = [x.strip() for x in os.environ['MCP_ALLOWED_IPS'].split(',') if x.strip()]


def redact(x):
    return SENSITIVE.sub(lambda m: m.group(1)+'[REDACTED]', str(x))


def audit(x):
    logdir = BASE / 'logs'; logdir.mkdir(exist_ok=True)
    with open(str(logdir/'operations.log'),'a',encoding='utf-8') as f:
        f.write('[{}] {}\n'.format(datetime.datetime.now().isoformat(), redact(x)))


def root(): return Path(str(CFG['project_root'])).resolve()

def inside(p, parent):
    try: p.resolve().relative_to(parent.resolve()); return True
    except ValueError: return False

def clean_path(value):
    if not isinstance(value, str) or not value or '\x00' in value: raise ValueError('path 无效')
    if ':' in value or value.startswith(('/', '\\')) or '\\' in value: raise ValueError('只允许使用相对路径和正斜杠')
    parts = value.split('/')
    if '..' in parts or any(not p or p == '.' for p in parts): raise ValueError('禁止路径穿越或非法路径段')
    return '/'.join(parts)

def project_path(value):
    rel = clean_path(value); p = (root()/rel).resolve()
    if not inside(p, root()): raise ValueError('路径不在项目根目录内')
    return p, rel

def sensitive(rel):
    low = rel.lower(); name = low.split('/')[-1]
    return name in ('.env','frpc.toml','frpc.ini') or name.endswith(('.key','.pem')) or any(x in low.split('/') for x in ('.git','node_modules','target','__pycache__')) or re.search(r'(?i)(api[_-]?key|token|password|secret)', name) is not None

def allowed_read(rel):
    return not sensitive(rel) and (rel in READ_FIXED or (rel.startswith('plugin-template/src/main/java/') and rel.endswith('.java')) or rel.startswith('plugin-template/src/main/resources/'))

def allowed_write(rel):
    return not sensitive(rel) and (rel in WRITE_FIXED or (rel.startswith('plugin-template/src/main/java/') and rel.endswith('.java')) or rel.startswith('plugin-template/src/main/resources/'))

def limit(x):
    x = redact(x or ''); n = int(CFG['max_output_size']); return x if len(x)<=n else x[:n]+'\n...[truncated]'

def sha(p):
    h=hashlib.sha256()
    with open(str(p),'rb') as f:
        for b in iter(lambda:f.read(65536),b''): h.update(b)
    return h.hexdigest()

def run(argv,cwd):
    try:
        p=subprocess.Popen(argv,cwd=str(cwd),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=False,universal_newlines=True)
        try: out,err=p.communicate(timeout=int(CFG['command_timeout'])); timed=False
        except subprocess.TimeoutExpired:
            p.kill(); out,err=p.communicate(); timed=True; err += '\nCommand timed out'
        return {'argv':argv,'cwd':str(cwd),'exit_code':p.returncode if not timed else -1,'timeout':timed,'stdout':limit(out),'stderr':limit(err)}
    except Exception as e: return {'argv':argv,'cwd':str(cwd),'exit_code':-1,'timeout':False,'stdout':'','stderr':redact(e)}

def env_check():
    def v(c): return run(c,root())
    files=['backend/app/main.py','frontend/package.json','frontend/vite.config.ts','plugin-template/pom.xml']
    return {'python':v(['python','--version']),'node':v(['node','--version']),'npm':v(['npm','--version']),'java':v(['java','-version']),'maven':v(['mvn','-version']),'project_exists':root().is_dir(),'files':{x:(root()/x).is_file() for x in files}}

def call_tool(name,a):
    if name=='check_environment': return env_check()
    if name=='list_project_files':
        maxn=max(1,min(int(a.get('max_files',500)),2000)); out=[]
        for cur,dirs,files in os.walk(str(root())):
            dirs[:]=[d for d in dirs if d not in IGNORED and not d.startswith('.')]
            for f in files:
                p=Path(cur)/f
                try: rel=str(p.resolve().relative_to(root())).replace('\\','/')
                except ValueError: continue
                if not sensitive(rel): out.append(rel)
                if len(out)>=maxn: return {'files':sorted(out),'truncated':True}
        return {'files':sorted(out),'truncated':False}
    if name=='read_project_file':
        p,rel=project_path(a.get('path'))
        if not allowed_read(rel): raise PermissionError('文件不在允许读取列表中')
        if not p.is_file(): raise FileNotFoundError('文件不存在')
        if p.stat().st_size>int(CFG['max_file_size']): raise ValueError('文件过大')
        return {'path':rel,'size':p.stat().st_size,'sha256':sha(p),'content':redact(p.read_text(encoding='utf-8',errors='replace'))}
    if name=='write_project_file':
        if not CFG['allow_write']: raise PermissionError('写入已禁用')
        p,rel=project_path(a.get('path')); content=a.get('content'); reason=a.get('reason','')
        if not allowed_write(rel): raise PermissionError('文件不在允许修改列表中')
        if not isinstance(content,str) or not reason.strip(): raise ValueError('content 和 reason 必须有效')
        size=len(content.encode('utf-8'))
        if size>int(CFG['max_file_size']): raise ValueError('文件过大')
        if CFG['require_confirmation'] and a.get('confirm') is not True: return {'confirmation_required':True,'path':rel,'reason':reason,'new_size':size,'existing_file':p.exists()}
        backup=None; p.parent.mkdir(parents=True,exist_ok=True)
        if p.exists():
            b=root()/'.zjmc-pymcp-backups'; b.mkdir(exist_ok=True); backup=str(b/(rel.replace('/','__')+'.'+time.strftime('%Y%m%d_%H%M%S')+'.bak')); Path(backup).write_bytes(p.read_bytes())
        tmp=p.with_name(p.name+'.zjmc.tmp'); tmp.write_text(content,encoding='utf-8'); os.replace(str(tmp),str(p)); digest=sha(p); audit('write {} reason={} sha256={}'.format(rel,reason,digest))
        return {'written':True,'path':rel,'size':size,'sha256':digest,'backup':backup}
    if name=='run_project_command':
        if not CFG['allow_command']: raise PermissionError('命令执行已禁用')
        action=a.get('action')
        if action not in COMMANDS: raise ValueError('不允许的 action')
        argv,where=COMMANDS[action]; cwd=root() if where=='root' else root()/where; audit('command '+action); return run(argv,cwd)
    if name=='read_build_log':
        logs=BASE/'logs'; files=sorted([p for p in logs.glob('*') if p.is_file()],key=lambda p:p.stat().st_mtime,reverse=True) if logs.exists() else []
        if not files: return {'found':False,'content':'','maven_errors':[]}
        text=redact(files[0].read_text(encoding='utf-8',errors='replace')); return {'found':True,'file':files[0].name,'content':text[-min(int(a.get('max_length',20000)),100000):],'maven_errors':[x for x in text.splitlines() if '[ERROR]' in x][:100]}
    if name=='validate_project':
        result=[]; py=root()/'backend/app/main.py'
        if py.is_file():
            try: compile(py.read_text(encoding='utf-8'),str(py),'exec'); result.append({'type':'python_syntax','ok':True})
            except SyntaxError as e: result.append({'type':'python_syntax','ok':False,'line':e.lineno,'message':str(e)})
        else: result.append({'type':'python_syntax','ok':False,'message':'main.py 不存在'})
        for x in ['frontend/package.json','frontend/vite.config.ts','plugin-template/pom.xml']:
            result.append({'type':'file','path':x,'ok':(root()/x).is_file()})
        for cur,dirs,files in os.walk(str(root()/'plugin-template/src/main/java')):
            for f in files:
                if f.endswith('.java'):
                    p=Path(cur)/f; text=p.read_text(encoding='utf-8',errors='replace'); result.append({'type':'java','path':str(p.relative_to(root())).replace('\\','/'),'ok':'import org.bukkit.PotionEffect;' not in text and 'import org.bukkit.PotionEffectType;' not in text,'wrong_imports':['org.bukkit.PotionEffect' if 'import org.bukkit.PotionEffect;' in text else None,'org.bukkit.PotionEffectType' if 'import org.bukkit.PotionEffectType;' in text else None],'join_welcome_logic':'PlayerJoinEvent' in text and 'sendMessage' in text})
        return {'diagnostics':result}
    raise ValueError('未知工具: '+str(name))

TOOLS=[{'name':'check_environment','description':'检查开发环境和项目结构','inputSchema':{'type':'object','properties':{}}},{'name':'list_project_files','description':'列出项目文件','inputSchema':{'type':'object','properties':{'max_files':{'type':'integer'}}}},{'name':'read_project_file','description':'读取允许的项目文件','inputSchema':{'type':'object','required':['path'],'properties':{'path':{'type':'string'}}}},{'name':'write_project_file','description':'确认后写入项目文件','inputSchema':{'type':'object','required':['path','content','reason'],'properties':{'path':{'type':'string'},'content':{'type':'string'},'reason':{'type':'string'},'confirm':{'type':'boolean'}}}},{'name':'run_project_command','description':'运行固定白名单命令','inputSchema':{'type':'object','required':['action'],'properties':{'action':{'type':'string','enum':list(COMMANDS.keys())}}}},{'name':'read_build_log','description':'读取最近日志','inputSchema':{'type':'object','properties':{}}},{'name':'validate_project','description':'检查项目结构和代码问题','inputSchema':{'type':'object','properties':{}}}]

def authorized(req):
    ip=req.client.host if req.client else ''
    if CFG.get('allowed_ips') and ip not in CFG['allowed_ips']: return False
    token=str(CFG.get('access_token') or '')
    if not CFG.get('require_auth') and not token: return True
    h=req.headers.get('authorization','')
    return h.lower().startswith('bearer ') and token and secrets.compare_digest(h[7:].strip(),token)

async def rpc(req,p):
    if p.get('method')=='initialize': return {'jsonrpc':'2.0','id':p.get('id'),'result':{'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'ZJMC-PyMCP','version':'0.1.0'}}}
    if p.get('method') in ('notifications/initialized','ping'): return None if p.get('method').startswith('notifications') else {'jsonrpc':'2.0','id':p.get('id'),'result':{}}
    if p.get('method')=='tools/list': return {'jsonrpc':'2.0','id':p.get('id'),'result':{'tools':TOOLS}}
    if p.get('method')=='tools/call':
        try: data=call_tool(p.get('params',{}).get('name'),p.get('params',{}).get('arguments') or {}); err=False
        except Exception as e: data={'error':redact(e)}; err=True
        return {'jsonrpc':'2.0','id':p.get('id'),'result':{'content':[{'type':'text','text':json.dumps(data,ensure_ascii=False,indent=2)}],'isError':err}}
    return {'jsonrpc':'2.0','id':p.get('id'),'error':{'code':-32601,'message':'方法不支持'}}

@app.get('/health')
async def health(): return {'ok':True,'server':'ZJMC-PyMCP','protocol':'2024-11-05'}
@app.get('/mcp')
async def mcp(req:Request):
    if not authorized(req): return JSONResponse({'error':'unauthorized'},status_code=401)
    sid=str(uuid.uuid4()); sessions[sid]=time.time()
    async def stream():
        yield 'event: endpoint\\ndata: /messages/?session_id={}\\n\\n'.format(sid)
        try:
            while not await req.is_disconnected(): yield ': keepalive\\n\\n'; await asyncio.sleep(15)
        finally: sessions.pop(sid,None)
    return StreamingResponse(stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','Connection':'keep-alive'})
@app.post('/messages/')
async def messages(req:Request,session_id:str=''):
    if not authorized(req): return JSONResponse({'error':'unauthorized'},status_code=401)
    if session_id and session_id not in sessions: return JSONResponse({'error':'invalid session'},status_code=400)
    try: p=await req.json(); result=await rpc(req,p); return JSONResponse({'ok':True} if result is None else result)
    except Exception as e: return JSONResponse({'error':redact(e)},status_code=400)

if __name__=='__main__':
    load_config(); print('ZJMC-PyMCP listening on {}:{}'.format(CFG['bind_host'],CFG['bind_port'])); uvicorn.run(app,host=CFG['bind_host'],port=int(CFG['bind_port']))
