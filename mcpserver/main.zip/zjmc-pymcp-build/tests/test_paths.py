import os, sys, unittest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import server
class TestPaths(unittest.TestCase):
 def test_parent(self):
  with self.assertRaises(ValueError): server.clean_path('../x')
 def test_drive(self):
  with self.assertRaises(ValueError): server.clean_path('C:/x')
 def test_env(self): self.assertFalse(server.allowed_read('backend/.env'))
if __name__ == '__main__': unittest.main()
