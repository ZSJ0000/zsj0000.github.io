import os, sys, unittest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import server
class TestCommands(unittest.TestCase):
 def test_whitelist(self): self.assertIn('build_plugin', server.COMMANDS)
 def test_shell_false_config(self): self.assertFalse(server.CFG['allow_shell'])
if __name__ == '__main__': unittest.main()
