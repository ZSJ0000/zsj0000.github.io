import os, sys, unittest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import server
class TestPermissions(unittest.TestCase):
 def test_fixed(self): self.assertTrue(server.allowed_write('README.md'))
 def test_frpc(self): self.assertFalse(server.allowed_write('frpc.toml'))
 def test_node_modules(self): self.assertFalse(server.allowed_read('frontend/node_modules/a.js'))
if __name__ == '__main__': unittest.main()
