@echo off
chcp 65001 >nul
echo 请在运行 server.py 的窗口中按 Ctrl+C 停止服务。
pause
