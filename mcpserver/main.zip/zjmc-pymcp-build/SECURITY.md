# Security

The server is restricted to the configured project root. It blocks traversal, absolute paths, `.env`, frp configuration, credentials, `.git`, `node_modules`, `target`, and `__pycache__`. Writes require `confirm=true`, are size limited, and create backups under `.zjmc-pymcp-backups`. Commands are fixed actions executed with `shell=False`, timeout, and output limits. Never expose this service directly without HTTPS, authentication, IP restrictions, and a reverse proxy. OAuth is not fully implemented locally; configure it at the public proxy.
