@echo off
chcp 65001 >nul
cd /d C:\zjmc-pymcp
if not exist logs mkdir logs
python server.py
