# ZJMC-PyMCP

Python 3.8 compatible MCP SSE server for the ZJMC-AI Minecraft project.

## Run

1. Copy `config.json.example` to `config.json`.
2. Review the project root and security switches.
3. Install manually: `python -m pip install -r requirements.txt`.
4. Start with `python server.py` or `start_mcp.bat`.
5. Health endpoint: `http://127.0.0.1:8787/health`.
6. MCP SSE endpoint: `http://127.0.0.1:8787/mcp`.

This package uses the 2024-11-05 style MCP SSE transport. It does not implement a complete OAuth authorization server or JWT/JWKS validation. For public deployment use HTTPS, an OAuth-capable reverse proxy, a strong Bearer token, firewall rules, and frp only as a tunnel.
