EcoEnchants 2026.30 package

plugin/EcoEnchants-2026.30-all.jar: 插件主文件。
eco/eco-2026.30-all.jar: 直接依赖。
libreforge/libreforge-2026.30-all.jar: 依赖的依赖。
