Fresh official fork build: EcoEnchants 2026.30.
