Win7 OAuth MCP SSE Server
Python 3.8.10 compatible. Edit config.py, install requirements, then run start_https.bat.
Certificate files are not included.
