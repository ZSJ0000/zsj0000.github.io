Do not put private keys in public repositories. Configure certificate paths in config.py.
