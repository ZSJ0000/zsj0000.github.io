@echo off
cd /d "%~dp0"
python -m uvicorn mcp_oauth_server.app:app --host 127.0.0.1 --port 26876
pause
