@echo off
cd /d "%~dp0"
python -m uvicorn mcp_oauth_server.app:app --host 0.0.0.0 --port 26876 --ssl-certfile "C:\zjmc-pymcp\certs\fullchain.pem" --ssl-keyfile "C:\zjmc-pymcp\certs\privkey.pem"
pause
