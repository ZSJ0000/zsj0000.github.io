MCP_BASE_URL = "https://zj0.qd.je:26876"
HOST = "0.0.0.0"
PORT = 26876
CERT_FILE = r"C:\zjmc-pymcp\certs\fullchain.pem"
KEY_FILE = r"C:\zjmc-pymcp\certs\privkey.pem"
JWT_SECRET = "CHANGE_THIS_TO_A_LONG_RANDOM_SECRET"
USER_NAME = "admin"
USER_PASSWORD = "CHANGE_THIS_PASSWORD"
