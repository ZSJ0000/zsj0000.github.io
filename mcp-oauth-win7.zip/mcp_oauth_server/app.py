# -*- coding: utf-8 -*-
import asyncio, base64, hashlib, secrets, time
from typing import Optional
from urllib.parse import parse_qs, urlparse, urlencode
import jwt
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse, StreamingResponse
import config
app=FastAPI(title='OAuth MCP SSE Server')
CLIENTS={'mcp-client':{'redirect_uris':['http://127.0.0.1:*/callback','http://localhost:*/callback']}}
CODES={}
def enc(b): return base64.urlsafe_b64encode(b).rstrip(b'=').decode()
def redirect_ok(u, xs): return any(u==x or (x.endswith('*') and u.startswith(x[:-1])) for x in xs)
def auth(req):
 v=req.headers.get('authorization','')
 if not v.lower().startswith('bearer '): raise HTTPException(401,'missing_token',headers={'WWW-Authenticate':'Bearer'})
 try: return jwt.decode(v[7:].strip(),config.JWT_SECRET,algorithms=['HS256'])
 except Exception: raise HTTPException(401,'invalid_token',headers={'WWW-Authenticate':'Bearer'})
@app.get('/.well-known/oauth-authorization-server')
async def metadata(): return {'issuer':config.MCP_BASE_URL,'authorization_endpoint':config.MCP_BASE_URL+'/authorize','token_endpoint':config.MCP_BASE_URL+'/token','response_types_supported':['code'],'grant_types_supported':['authorization_code'],'code_challenge_methods_supported':['S256'],'token_endpoint_auth_methods_supported':['none'],'scopes_supported':['mcp']}
@app.get('/authorize',response_class=HTMLResponse)
async def authorize(response_type:str,client_id:str,redirect_uri:str,code_challenge:str,state:Optional[str]=None,scope:str='mcp'):
 c=CLIENTS.get(client_id)
 if response_type!='code' or not c or not redirect_ok(redirect_uri,c['redirect_uris']): raise HTTPException(400,'invalid_request')
 q='?'+urlencode({'response_type':response_type,'client_id':client_id,'redirect_uri':redirect_uri,'code_challenge':code_challenge,'state':state or '','scope':scope})
 return HTMLResponse('<meta charset="utf-8"><h3>MCP 授权</h3><form method="post" action="/authorize/approve"><input type="hidden" name="q" value="'+q.replace('&','&amp;')+'">用户名：<input name="username"><br>密码：<input type="password" name="password"><br><button>授权</button></form>')
@app.post('/authorize/approve')
async def approve(q:str=Form(...),username:str=Form(...),password:str=Form(...)):
 if username!=config.USER_NAME or password!=config.USER_PASSWORD: raise HTTPException(401,'invalid_login')
 p=parse_qs(q.lstrip('?')); code=secrets.token_urlsafe(32); CODES[code]={'client_id':p['client_id'][0],'redirect_uri':p['redirect_uri'][0],'challenge':p['code_challenge'][0],'scope':p.get('scope',['mcp'])[0],'exp':time.time()+300,'sub':username}
 out={'code':code};
 if p.get('state',[''])[0]: out['state']=p['state'][0]
 return RedirectResponse(CODES[code]['redirect_uri']+'?'+urlencode(out),302)
@app.post('/token')
async def token(grant_type:str=Form(...),code:str=Form(...),client_id:str=Form(...),redirect_uri:str=Form(...),code_verifier:str=Form(...)):
 x=CODES.pop(code,None)
 if grant_type!='authorization_code' or not x or x['exp']<time.time() or x['client_id']!=client_id or x['redirect_uri']!=redirect_uri or enc(hashlib.sha256(code_verifier.encode()).digest())!=x['challenge']: raise HTTPException(400,'invalid_grant')
 now=int(time.time()); t=jwt.encode({'sub':x['sub'],'client_id':client_id,'scope':x['scope'],'iat':now,'exp':now+1800},config.JWT_SECRET,algorithm='HS256')
 return {'access_token':t,'token_type':'Bearer','expires_in':1800,'scope':x['scope']}
@app.get('/sse')
async def sse(request:Request):
 auth(request)
 async def stream():
  yield 'event: endpoint\ndata: /messages\n\n'
  while not await request.is_disconnected(): await asyncio.sleep(15); yield ': keepalive\n\n'
 return StreamingResponse(stream(),media_type='text/event-stream',headers={'Cache-Control':'no-cache','Connection':'keep-alive'})
@app.post('/messages')
async def messages(request:Request):
 auth(request); b=await request.json(); m=b.get('method'); r={'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'win7-oauth-mcp','version':'0.1.0'}} if m=='initialize' else ({'tools':[]} if m=='tools/list' else {})
 return JSONResponse({'jsonrpc':'2.0','id':b.get('id'),'result':r})
